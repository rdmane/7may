﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Web.Security;
using System.Data;
namespace MyProject
{
    public partial class Checkout : System.Web.UI.Page
    {
        protected void Group1_CheckedChanged(Object sender, EventArgs e)
        {
            if (rdb1.Checked)
            {
                
            }

             
               
        }
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnid_Click(object sender, EventArgs e)
        {
            if (txtaddrress.Text != string.Empty)
            {
                DataTable dt = new DataTable();
                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["shopingConnectionString1"].ConnectionString);
                string valCmd = "select * from completeCart where uName='" + Session["name"] + "'";
                SqlCommand CMD = new SqlCommand(valCmd, con);
                SqlDataAdapter sd = new SqlDataAdapter(CMD);
                sd.Fill(dt);
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    // DataRow row = dt.Rows[i];
                    // DataRow nextRow = dt.Rows[i + 1];
                    var name = dt.Rows[i][1].ToString();
                    var pname = dt.Rows[i][2].ToString();
                    var quantity = dt.Rows[i][5].ToString();
                    var price = dt.Rows[i][6].ToString();
                    con.Open();
                    string cmd = "insert into cart(uName,pName,quantity,status,price)values('" + name + "','" + pname + "','" + quantity + "',1,'" + price + "') ";
                    SqlCommand Cmd = new SqlCommand(cmd, con);

                    Cmd.ExecuteNonQuery();
                    con.Close();
                }
                con.Open();
                string cmd1 = "delete from completeCart where uName='" + Session["name"] + "'";
                SqlCommand Cmd1 = new SqlCommand(cmd1, con);
                Cmd1.ExecuteNonQuery();
                lblconfirm.Visible = true;
                lblconfirm.Text = "You order has been Place successfully";
            }
            else
            {
                lblconfirm.Visible = true;
                lblconfirm.Text = "Please write devivery address ";   
            }
        }
    }
}