﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net;
using System.Net.Mail;

namespace MyProject
{
    public partial class ContactUs : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            SendMail();
        }
        protected void SendMail()
        {
            MailMessage mm = new MailMessage("amar@gmail.com", "ramgaikwad456789@gmail.com");

            //  mm.Subject = txtSubject.Text;

            mm.Body = "Name: " + txtname.Text + "<br /><br />Email: " + email.Text + "<br />Message:" + message.Text;

            //if (FileUpload1.HasFile)
            //{

            //    string FileName = System.IO.Path.GetFileName(FileUpload1.PostedFile.FileName);

            //    mm.Attachments.Add(new Attachment(FileUpload1.PostedFile.InputStream, FileName));

            //}

            mm.IsBodyHtml = true;

            SmtpClient smtp = new SmtpClient();

            smtp.Host = "smtp.gmail.com";

            smtp.EnableSsl = true;

            System.Net.NetworkCredential NetworkCred = new System.Net.NetworkCredential();

            NetworkCred.UserName = "ramgaikwad456789@gmail.com";

            NetworkCred.Password = "123456suraj";

            smtp.UseDefaultCredentials = true;

            smtp.Credentials = NetworkCred;

            smtp.Port = 587;

            smtp.Send(mm);

            lblMessage.Text = "Email Sent SucessFully.";
        }
    }
}